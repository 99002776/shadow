package com.boat.controller;

 

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

 

import com.boat.bean.EngineData;
import com.boat.bean.Vehicle;
import com.boat.services.BoatService;

 

@RestController
public class BoatController {
    @Autowired
    BoatService boatservice;
    
    @PostMapping("/boat/post")
    public String postController(@RequestBody Vehicle vehicle)
    {
        System.out.println("in post");
        boatservice.vehicleRegister(vehicle);
        
        return"sucessfully posted"; 
        
    }
    
    
        @Autowired
        private KafkaTemplate<String, EngineData> kafkaTemplate;
        private static final String TOPIC = "BoatData";

        @GetMapping("/event")
        public String post() throws IOException {
        	
        	boatservice.BoatEventData();
            return "Published successfully";
            
        }
        
        
        
        
}