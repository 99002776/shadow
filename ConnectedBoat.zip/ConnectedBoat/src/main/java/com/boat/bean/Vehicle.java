package com.boat.bean;

import org.springframework.context.annotation.Scope;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//@Scope("singleton")

public class Vehicle {
	
	private String hin;
	private Integer fuel_capacity;
	private String engine_type;
	private Integer max_speed;
	

}
