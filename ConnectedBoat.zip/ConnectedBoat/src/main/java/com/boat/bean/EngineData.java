package com.boat.bean;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EngineData {
	
	private String hin;
	private Integer engine_rpm;
	private Double engine_temperature;
	private Integer current_fuel;
	private Double latitude;
	private Double longitude;
	private String timestamp;
	private Integer heading;
    private Integer speed;

}
