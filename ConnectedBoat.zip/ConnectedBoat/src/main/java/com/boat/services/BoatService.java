package com.boat.services;

 

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import com.boat.bean.EngineData;
import com.boat.bean.Vehicle;
//import com.ltts.exve.carsim.bean.VehicleSimulationBMW;
import com.boat.bean.BoatEvent;
//import com.ltts.exve.carsim.bean.VehicleSimulationAudi;
@Service    
public class BoatService {
    
    
    Map<Integer,EngineData> boatMap = new HashMap<Integer, EngineData>();
    
    @Autowired
	BoatUtil boatutil;
    
    String hin;
    
    Map<String, Vehicle> vehicleMap = new HashMap<String, Vehicle>();
    
    public BoatService() {
        super();
        // TODO Auto-generated constructor stub
    }
    
      @Autowired
        private KafkaTemplate<String, EngineData> kafkaTemplate;
        private static final String TOPIC = "BoatData";

        @Autowired
        private KafkaTemplate<String, BoatEvent> kafkaTemplateEvent;
        private static final String TOPICS = "BoatEvent";
        
        @Autowired
        private KafkaTemplate<String, Vehicle> kafkaTemplateVehicle;
        private static final String VTOPICS = "vehicle";

//    public void postBoatdata(EngineData boatdata) {
//        // TODO Auto-generated method stub
//        boatMap.put(boatdata.getId(),boatdata);
//        // System.out.println(boatMap);
//         kafkaTemplate.send(TOPIC, boatdata);
//        
//    }



	public void BoatEventData() throws IOException {
		// TODO Auto-generated method stub
		BoatEvent boatevent = new BoatEvent();
		boatevent.setAltitude(boatutil.getRandomNumber(755,765));
		boatevent.setBatterychargestatus(20);
		boatevent.setHeading(boatutil.getRandomNumber(-180,180));
		boatevent.setHin(boatutil.getAlphaNumericString(12));
		boatevent.setIdle(false);
		boatevent.setIgnitionstatus(true);
		boatevent.setLatitude(boatutil.readLatitude());
		boatevent.setLongitude(boatutil.readLongitude());
		boatevent.setLightstatus(false);
		boatevent.setSpeed(40);
		boatevent.setSteeringangle(boatutil.getRandomNumberDouble(0, 180));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        Date now = new Date();
        String strDate = sdf.format(now);
        boatevent.setTimestamp(strDate);
        kafkaTemplateEvent.send(TOPICS,boatevent);
		
	}

	public void vehicleRegister(Vehicle vehicle) {
		// TODO Auto-generated method stub
		hin=vehicle.getHin();
		vehicleMap.put(vehicle.getHin(), vehicle);
		 kafkaTemplateVehicle.send(VTOPICS,vehicle);
		
	}
	
	
	public String pushEngineData() throws IOException {
		EngineData enginedata= new EngineData();
		Vehicle vehicle=vehicleMap.get(hin);
		if(vehicle!=null) {
			
			enginedata.setCurrent_fuel(boatutil.getRandomNumber(0, 10));
			enginedata.setEngine_rpm(boatutil.getRandomNumber(0, 3000));
			enginedata.setEngine_temperature(boatutil.getRandomNumberDouble(0, 100));
			enginedata.setHeading(boatutil.getRandomNumber(-180, 180));
			enginedata.setHin(hin);
			enginedata.setLatitude(boatutil.readLatitude());
			enginedata.setLongitude(boatutil.readLongitude());
			enginedata.setSpeed(boatutil.getRandomNumber(10, 120));
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	        Date now = new Date();
	        String strDate = sdf.format(now);
	        enginedata.setTimestamp(strDate);
	        kafkaTemplate.send(TOPIC,enginedata);
			return"Sucessfully Posted to Consumer";
		}
		else
		{
			return "No Vehicle data";
		}
	}

	


}