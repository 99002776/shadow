package com.boat.services;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class BoatUtil {

	@Value("${excelFile.url}") 
	private String excelFileUrl;
	
	public static int rowcount=0;
	public static int rowcount1=0;
	
	
//	/**
//	 * getRandomElement Storing DTC in Array 
//	 * 
//	 */
//	public String getRandomElement() 
//    { 
//		String[] dtc_list = new String[]{"P0301", "P0302", "P0303", "P0304", "P0305","P0306","P0307","P0405","P0406","P0505","P0609",
//				"P0308","P0309","P0205","P0206","P0202","P0201","P0203","P0105","P0104","P0107","P0108","P0208","P0404","P0605","P0608"};
//        Random rand = new Random(); 
//     return dtc_list[rand.nextInt(dtc_list.length)]; 
//    } 
	
	
	
	/**
	 * getRandomNumber 
	 * 
	 */
	public Double getRandomNumberDouble(int min, int max) {
		DecimalFormat df = new DecimalFormat("###.##");
		Double randomNumber = (Math.random() * (max - min + 1) + min);
		return Double.parseDouble(df.format(randomNumber));
	}
	
//	private Integer calculateSpeedFromRpm(Double double1,String vin) {
//		Integer diameter =getRandomNumber(29,31) ;	
//  	int speed= (int) (((Math.PI ) * (double1 )* (diameter)/1056) * 1.609344);
//  	if(speed<=200)
//  	{
//  		return speed;
//  	}
//  	else
//  		return getRandomNumber(150,200);
//	}
	
	/**
	 * Creating random number
	 * @param min
	 * @param max
	 * @return
	 */
	public Integer getRandomNumber(int min, int max) {
		Integer randomNumber = (int)(Math.random() * (max - min + 1) + min);
		return randomNumber;
	}
	
	

	/**
	 * readDataFromExcel Method read location data from ExcelFile for latitude
	 */
	public Double readLatitude()throws IOException{
		
		try {
			 InputStream file= (InputStream) this.getClass().getResourceAsStream(excelFileUrl);
	    	  @SuppressWarnings("resource")
			XSSFWorkbook myExcelBook = new XSSFWorkbook(file);
	    	   XSSFSheet myExcelSheet =myExcelBook.getSheetAt(0); 
	    	   if(rowcount<98)
				{ 
					Row row = myExcelSheet.getRow(rowcount); 
					if(row.getCell(0).getCellType() == HSSFCell.CELL_TYPE_NUMERIC){ 
						double latitude = row.getCell(0).getNumericCellValue();
						return latitude;	
					}
				}
	    	   else
				{
					Row row = myExcelSheet.getRow(rowcount); 
					if(row.getCell(0).getCellType() == HSSFCell.CELL_TYPE_NUMERIC){ 
						double latitude = row.getCell(0).getNumericCellValue(); 
						return latitude;	
					}
					rowcount=0;	
					//logger.info("rowcount of simulation" +rowcount);
				}
				rowcount++;
			}catch(FileNotFoundException e) {
				System.out.println("Exception while reading Excel "+e);
			}
		return null;
	}
	
	
	
	
	
	/**
	 * readDataFromExcel Method read location data from ExcelFile for longitude
	 */
	public Double readLongitude()throws IOException{
		try {
			 InputStream file= (InputStream) this.getClass().getResourceAsStream(excelFileUrl);
	    	  @SuppressWarnings("resource")
			XSSFWorkbook myExcelBook = new XSSFWorkbook(file);
	    	   XSSFSheet myExcelSheet =myExcelBook.getSheetAt(0); 
				if(rowcount1<98)
				{ 
					Row row = myExcelSheet.getRow(rowcount1); 
					if(row.getCell(1).getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
						double longitude= row.getCell(1).getNumericCellValue(); 
						return longitude;
					}
					
				}
				else
				{
					Row row = myExcelSheet.getRow(rowcount1); 
					
					if(row.getCell(1).getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
						double longitude= row.getCell(1).getNumericCellValue(); 
						return longitude;
					}
					rowcount1=0;	
					
				}
				rowcount1++;
			}catch(FileNotFoundException e) {
				System.out.println("Exception while reading Excel "+e);
			}
		return null;
		}
	
	
	/**
	 * creating Random Hin number for boats
	 * @param n
	 * @return
	 */
	static String getAlphaNumericString(int n) 
    { 
  
        // chose a Character random from this String 
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                    + "0123456789"
                                    + "abcdefghijklmnopqrstuvxyz"; 
  
        // create StringBuffer size of AlphaNumericString 
        StringBuilder sb = new StringBuilder(n); 
  
        for (int i = 0; i < n; i++) { 
  
            // generate a random number between 
            // 0 to AlphaNumericString variable length 
            int index 
                = (int)(AlphaNumericString.length() 
                        * Math.random()); 
  
            // add Character one by one in end of sb 
            sb.append(AlphaNumericString 
                          .charAt(index)); 
        } 
  
        return sb.toString(); 
    } 
	
	
	

}
